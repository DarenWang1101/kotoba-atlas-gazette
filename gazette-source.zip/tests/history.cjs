const assert=require('node:assert/strict'),fs=require('fs'),H=require('../dist/history-core.js'),{waves}=require('../dist/history.json');
assert.deepEqual(waves.map(w=>w.year),[2006,2009,2012,2015,2018,2021,2024]);
for(const w of waves){assert.equal(new Set(w.rows.map(d=>d.id)).size,w.rows.length);for(const k of ['learners','teachers','institutions'])assert.equal(w.rows.reduce((s,d)=>s+(d[k]??0),0),w.totals[k],`${w.year} ${k}`);assert(w.rows.every(d=>d.stages.length===4));for(const d of w.rows){const st=[...H.stages(d),d.multipleStage??0];if(st.every(Number.isFinite))assert.equal(st.reduce((a,b)=>a+b,0),d.learners,`${w.year} ${d.id}`)}}
assert.equal(H.series(waves,'world','primary')[0].value,null);
assert.equal(H.series(waves,'world','school')[0].value,1700744);
assert.equal(H.series(waves,'world','multipleStage')[1].value,176793);
assert.equal(H.series(waves,'world','multipleStage')[2].value,177479);
assert.equal(H.series(waves,'world','multipleStage')[3].value,null);
assert(H.series(waves,'country:ZZ','learners').every(x=>x.value===null));
assert(H.indexed([{value:null},{value:100}]).every(x=>x.value===null));
assert.equal(H.indexed([{value:50},{value:100}])[1].value,200);
console.log('PASS: seven complete country tables, source total reconciliation, native stages, missing observations and index baselines.');
