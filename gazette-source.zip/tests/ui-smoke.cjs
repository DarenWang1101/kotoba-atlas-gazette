// Headless logic smoke check, not a substitute for browser visual QA.
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),D=require('../dist/d3.min.js'),C=require('../dist/cluster-core.js'),H=require('../dist/history-core.js'),R=require('../dist/ratio-core.js');
const nodes=new Map(),captures=[];
function el(s){if(!nodes.has(s))nodes.set(s,{value:'',checked:false,innerHTML:'',style:{},disabled:false,classList:{toggle(){} ,remove(){}},querySelectorAll:()=>[],querySelector:()=>null,setAttribute(){},showModal(){this.open=true},close(){this.open=false}});return nodes.get(s)}
class Sel{constructor(rows=[]){this.rows=rows}remove(){return this}call(){return this}selectAll(){return new Sel(this.rows)}data(rows){this.rows=rows;captures.push(rows);return this}join(){return this}attr(name,val){for(let d of this.rows){let v=typeof val==='function'?val(d):val;assert(!String(v).includes('NaN'),name+' contains NaN')}return this}classed(){return this}style(){return this}on(){return this}append(){return this}text(f){this.rows.forEach(d=>typeof f==='function'&&f(d));return this}each(fn){this.rows.forEach(d=>fn.call({},d));return this}}
const context={document:{querySelector:el,querySelectorAll:()=>[]},d3:{...D,select:()=>new Sel()},AtlasCluster:C,AtlasHistory:H,AtlasRatio:R,AtlasProvinceMap:require('../dist/province-map-core.js'),console,setTimeout:f=>f()};vm.createContext(context);
vm.runInContext(fs.readFileSync('dist/app.js','utf8').replace(/;init\(\);/,';'),context);
for(let [s,v] of [['#clusterScope','all'],['#clusterK','4']])el(s).value=v;el('#depthToggle').checked=true;
// Assign mocks in the owning lexical context.
context.mock=new Sel();vm.runInContext(`data=${fs.readFileSync('dist/data.json')};world=${fs.readFileSync('dist/world.json')};covers=${fs.readFileSync('dist/covers.json')};adoptionEvidence=${fs.readFileSync('dist/adoption-evidence.json')};history=${fs.readFileSync('dist/history.json')};latestData=data;prepareHistory();projection=d3.geoNaturalEarth1().fitExtent([[15,25],[945,455]],{type:'Sphere'});features=mock;depthGroup=mock`,context);
for(let name of ['learners','institutions','teachers','learnerTeacher','learnersPopulation','books']){vm.runInContext(`layer='${name}';render()`,context);assert(el('#depthLegend').textContent.includes(name==='books'?'':'Height ='));if(name==='books'){assert(el('#depthToggle').disabled);assert(el('#countries').innerHTML.includes('みんなの日本語'));assert(el('#textbookChoice').innerHTML.includes('げんき'));}assert(!el('#countries').innerHTML.includes('undefined'));assert(!el('#countries').innerHTML.includes('NaN'))}
el('#depthToggle').checked=false;vm.runInContext("layer='learners';render()",context);assert(el('#depthLegend').textContent.startsWith('Flat map'));assert(!el('#depthToggle').disabled);
vm.runInContext("lastCluster={...AtlasCluster.cluster(data,AtlasCluster.groups.map(g=>g[0]),isKanji,4),rows:data,options:{scheme:scheme()}};renderClusters()",context);assert.equal((el('#clusterResults').innerHTML.match(/class="cluster-card"/g)||[]).length,4);assert(!el('#clusterResults').innerHTML.includes('NaN'));assert(!el('#clusterResults').innerHTML.includes('undefined'));
const html=fs.readFileSync('dist/index.html','utf8');assert(!html.includes('data-layer="background"'));assert(html.includes('id="backgroundFilter"'));assert(html.includes('id="depthToggle"'));assert(html.includes('cluster-core.js'));
console.log('PASS: three depth layers, distinct-title map, flat toggle, valid geometry, cluster card rendering and retained background controls.');

for(const y of [2006,2009,2012,2015,2018,2021,2024]){vm.runInContext(`setYear(${y})`,context);assert(!el('#details').innerHTML.includes('undefined'));assert(!el('#details').innerHTML.includes('NaN'));assert(el('#mapYear').textContent===y);for(const key of ['learners','teachers','school','primary','multipleStage']){el('#trendMetric').value=key;vm.runInContext('renderTrend()',context)}vm.runInContext("lastCluster={...AtlasCluster.cluster(data,['scale','stage','region','script'],isKanji,4),rows:data,options:{scheme:scheme()}};renderClusters()",context);assert(!el('#clusterResults').innerHTML.includes('NaN'));}
console.log('PASS: seven wave switches, country details, all trend series and historical clustering.');

vm.runInContext("setYear(2024);layer='books';chooseTextbook('げんき')",context);assert(el('#textbookPreview').innerHTML.includes('げんき'));assert(el('#legend').innerHTML.includes('げんき'));assert(!el('#depthLegend').textContent.includes('Height'));vm.runInContext('setYear(2021)',context);assert(el('#textbookExplorer').hidden);assert(!el('#depthToggle').disabled);console.log('PASS: textbook selection synchronizes map, title index and preview; historical wave restores count layer.');
vm.runInContext("trendScopes.add('country:US');trendScopes.add('region:East Asia');trendKeys.add('teachers');renderTrend()",context);
assert.equal((el('#trendSeriesLegend').innerHTML.match(/data-series=/g)||[]).length,6);
assert.equal((el('#trendTable').innerHTML.match(/<tr /g)||[]).length,42);
assert(el('#trendNotice').textContent.includes('Teacher definition break'));
vm.runInContext("hiddenTrendSeries.add('country:US|teachers');renderTrend()",context);
assert.equal((el('#trendTable').innerHTML.match(/<tr /g)||[]).length,35);
el('#trendMode').value='index';vm.runInContext('renderTrend()',context);assert(!el('#trendTable').innerHTML.includes('NaN'));
vm.runInContext("trendScopes.clear();renderTrend()",context);assert(el('#trendNotice').textContent.includes('Add at least one'));
assert.equal(vm.runInContext("flag('CN')",context),'🇨🇳');assert.equal(vm.runInContext("flag('HK')",context),'🇭🇰');assert(!html.includes('<i>海外日本語</i>'));assert(html.includes('COUNTRY/AREA-LEVEL SURVEY DATA'));
console.log('PASS: multi-area × multi-measure overlay, series visibility, empty selection, normalized mode and flags.');

vm.runInContext("setYear(2024);layer='books';chooseTextbook('いろどり')",context);assert(el('#adoptionEvidence').innerHTML.includes('48%'));assert(el('#adoptionEvidence').innerHTML.includes('30,651'));assert(el('#adoptionEvidence').innerHTML.includes('response shares'));vm.runInContext("chooseTextbook('みんなの日本語')",context);assert(el('#adoptionEvidence').innerHTML.includes('&gt;50%'));assert(el('#adoptionEvidence').innerHTML.includes('Japanese major'));console.log('PASS: scoped adoption bound and respondent/selection denominators remain distinct.');
context.document.addEventListener=()=>{};let tick=null,cleared=false;context.setInterval=f=>{tick=f;return 7};context.clearInterval=()=>{cleared=true;tick=null};
vm.runInContext('initWaveTransport();setYear(2024)',context);el('#wavePlay').onclick();assert.equal(vm.runInContext('currentYear',context),2006);tick();assert.equal(vm.runInContext('currentYear',context),2009);vm.runInContext('setYear(2018)',context);assert(cleared);assert.equal(el('#wavePlay').textContent,'▶ Play');
vm.runInContext("openTrendPoint({scope:'country:CN',key:'learners',label:'China · Learners',raw:AtlasHistory.series(history.waves,'country:CN','learners')},{year:2018})",context);assert(el('#trendPointDialog').open);assert(el('#trendPointTitle').textContent.includes('2018'));assert.equal(typeof el('#panelExport').onclick,'function');assert.equal((el('#trendTable').innerHTML.match(/<tr /g)||[]).length,7);
assert(html.indexOf('id="panelExport"')>html.indexOf('id="trendPointDialog"'));assert(html.indexOf('id="textbookExplorer"')>html.indexOf('class="map-wrap"'));assert(html.includes('reading-workspace'));assert(!fs.readFileSync('dist/app.js','utf8').includes('Title map ·'));
console.log('PASS: wave playback/step interruption, point-triggered source/CSV dialog, map profile placement and bounded reading section.');
// Exercise saved settings through the actual app initializer and ratio point dialog.
const checked=C.groups.map(([key])=>({dataset:{feature:key},checked:false,disabled:false}));
context.document.querySelectorAll=s=>s==='[data-feature]'?checked:s==='[data-feature]:checked'?checked.filter(e=>e.checked):[];
context.saved=require('../data/cluster_default.json');checked.forEach(e=>e.checked=context.saved.options.keys.includes(e.dataset.feature));
vm.runInContext('clusterDefault=saved;setYear(2024);initClusters()',context);
assert.equal(el('#clusterScope').value,'analysis');assert.equal(el('#clusterK').value,'2');assert.equal(el('#clusterEncoding').value,'tfidf');assert.equal(el('#clusterAlgorithm').value,'average');
assert.equal(vm.runInContext('lastCluster.rows.length',context),108);assert(!el('#clusterExport').disabled);assert(el('#clusterResults').innerHTML.includes('Textbook features'));assert(!el('#clusterResults').innerHTML.includes('Mean selected titles'));
vm.runInContext("trendScopes.clear();trendScopes.add('country:TW');trendKeys.clear();trendKeys.add('learnerTeacher');trendKeys.add('learnersPopulation');renderTrend();openTrendPoint({scope:'country:TW',key:'learnersPopulation',label:'Taiwan · Learners / 100k',raw:AtlasHistory.series(history.waves,'country:TW','learnersPopulation')},{year:2024})",context);
assert(el('#trendPointSummary').innerHTML.includes('23,400,220'));assert(el('#trendPointSummary').innerHTML.includes('all.pdf#page=32'));assert(!el('#trendTable').innerHTML.includes('NaN'));
console.log('PASS: saved clustering controls run the 108-area default, encoded profiles render, and ratio popup preserves denominator and source.');
context.geography=require('../data/institution_geography.json');
vm.runInContext("institutionGeography=geography;layer='institutions';setYear(2024);selectCountry('TW')",context);
assert(!el('#provinceExplorer').hidden);assert(el('#provinceSummary').textContent.includes('Taiwan'));assert(el('#provinceProfile').innerHTML.includes('808'));assert(el('#provinceProfile').innerHTML.includes('809'));
el('#provinceChoice').value='台北市';el('#provinceChoice').onchange();assert(el('#provinceProfile').innerHTML.includes('台北市'));
vm.runInContext('setYear(2021)',context);assert(el('#provinceExplorer').hidden);vm.runInContext("setYear(2024);layer='books';render()",context);assert(el('#provinceExplorer').hidden);vm.runInContext("layer='institutions';selectCountry('AL')",context);assert(el('#provinceExplorer').hidden);
assert(vm.runInContext("trendBreak('learnersPopulation',2021,2024)",context));assert(html.indexOf('id="provinceExplorer"')>html.indexOf('class="map-wrap"'));assert(html.indexOf('id="provinceExplorer"')<html.indexOf('class="map-foot"'));
const geo=context.geography;assert.equal(geo.source_record_count,19330);assert.equal(geo.coverage_areas,21);assert.equal(geo.areas.reduce((n,a)=>n+a.subdivisions.length,0),478);for(const a of geo.areas)assert.equal(a.subdivisions.reduce((n,s)=>n+s.directory_records,0)+a.unlocated_records,a.directory_records);assert.equal(geo.areas.find(a=>a.area_id==='TW').source_country_labels.length,2);
console.log('PASS: map-only province drilldown, Taiwan merge, directory/survey distinctions, historical hiding and 2024 population-source break.');
