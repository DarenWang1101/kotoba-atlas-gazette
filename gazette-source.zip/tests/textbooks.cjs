const assert=require('node:assert/strict'),fs=require('node:fs'),crypto=require('node:crypto');
const data=require('../dist/data.json'),records=require('../data/textbook_evidence.json'),reviews=require('../data/profile_reviews.json'),audit=require('../dist/textbook-audit.json'),evidence=require('../dist/adoption-evidence.json');
const books=data.flatMap(d=>(d.books||[]).map(b=>({...b,country:d.id})));
assert.equal(books.length,records.length);assert.equal(audit.totalRecords,records.length);
assert.equal(new Set(records.map(r=>r.evidence_id)).size,records.length,'Evidence IDs must be unique');
const areaIds=new Set(data.map(a=>a.id));
for(const r of records){assert(areaIds.has(r.area_id));assert(r.source_url.startsWith('https://www.jpf.go.jp/'));assert(r.source_title.trim());assert(r.pdf_pages.length&&r.pdf_pages.every(p=>Number.isInteger(p)&&p>0));assert(r.evidence_type);assert(r.adoption);if(r.adoption.status==='not_reported')assert.equal(r.adoption.value,null);if(r.adoption.value!=null){assert(r.adoption.scope);assert(r.adoption.value>=0&&r.adoption.value<=100)}}
const tw=books.filter(b=>b.country==='TW');assert.equal(tw.length,6);assert(tw.every(b=>b.sourcePages.includes(7)));assert(tw.some(b=>b.sourceTitle==='大家的日本語'&&b.evidenceStatus==='reported_use'));assert(tw.some(b=>b.sourceTitle==='新・楽しい子どもの日本語'&&b.evidenceStatus==='mentioned'));
for(const area of data){assert(area.reviewStatus);if(area.reviewStatus==='reviewed_no_named_titles')assert.deepEqual(area.books,[]);if(area.reviewStatus==='source_unavailable')assert.equal(area.books,undefined)}
for(const e of evidence.records){assert(e.denominator>0);assert(e.numerator<=e.denominator);assert(e.percent>=0&&e.percent<=100);assert(e.sourceURL.startsWith('https://www.jpf.go.jp/'));assert(Math.abs(e.numerator/e.denominator*100-e.percent)<.51);assert(e.rateType!=='national_adoption')}
const manifest=require('../data/datapackage.json');for(const r of manifest.resources){const bytes=fs.readFileSync('data/'+r.path);assert.equal('sha256:'+crypto.createHash('sha256').update(bytes).digest('hex'),r.hash);assert.deepEqual(bytes,fs.readFileSync('dist/open-data/'+r.path),'Published table must match repository table')}
console.log(`PASS: ${records.length} uniquely identified page-linked records, Taiwan alignment, scope/null semantics and published resource hashes.`);
