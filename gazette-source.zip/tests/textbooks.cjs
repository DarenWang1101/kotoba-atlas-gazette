const assert=require('node:assert/strict'),data=require('../dist/data.json'),audit=require('../dist/textbook-audit.json'),evidence=require('../dist/adoption-evidence.json');
const books=data.flatMap(d=>(d.books||[]).map(b=>({...b,country:d.id})));
assert.equal(books.length,129);assert.equal(audit.previousRecordAudit.length,61);assert.equal(audit.notMappedAsAdopted.length,14);
for(const b of books){assert(b.sourceUrl.startsWith('https://www.jpf.go.jp/'));assert(b.page>0);assert(b.evidenceStatus);assert(b.adoption);if(b.adoption.status==='not_reported')assert.equal(b.adoption.value,null)}
assert.equal(books.filter(b=>b.adoption.status==='reported_lower_bound').length,1);assert.equal(books.find(b=>b.adoption.status==='reported_lower_bound').country,'BR');
for(const e of evidence.records){assert(e.denominator>0);assert(e.numerator<=e.denominator);assert(e.percent>=0&&e.percent<=100);assert(e.sourceURL.startsWith('https://www.jpf.go.jp/'));assert(Math.abs(e.numerator/e.denominator*100-e.percent)<.51);assert(e.rateType!=='national_adoption')}
console.log('PASS: 61 audited prior records, 129 sourced renewed records, excluded publication-only items, rate bounds and quantitative denominators.');
