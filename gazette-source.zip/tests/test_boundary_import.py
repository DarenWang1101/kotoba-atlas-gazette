import importlib.util,pathlib,unittest
p=pathlib.Path(__file__).resolve().parents[1]/'scripts/import-subdivision-boundaries.py'; spec=importlib.util.spec_from_file_location('adm1',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Tests(unittest.TestCase):
 def test_match_and_ambiguity(self):
  directory={'areas':[{'area_id':'AA','subdivisions':[{'label':'北州','directory_records':5},{'label':'南市','directory_records':1}]},{'area_id':'BB','subdivisions':[{'label':'北州','directory_records':7}]}]}
  def f(country,name,n):return {'type':'Feature','properties':{'iso_a2':country,'name':name},'geometry':{'type':'Polygon','coordinates':[[[n,0],[n+1,0],[n,1],[n,0]]]}}
  geo={'features':[f('AA','North',1),f('BB','North',2)]}
  output,audit=m.convert(geo,directory,{'AA|北州':['North'],'BB|北州':['North']})
  self.assertEqual(len(output['features']),2);self.assertEqual([x['status'] for x in audit],['matched','unmatched','matched'])
  geo['features'].append(f('AA','North',3));o,a=m.convert(geo,directory,{'AA|北州':['North'],'BB|北州':['North']})
  self.assertEqual(a[0]['status'],'ambiguous');self.assertEqual(len(o['features']),1)
 def test_cities_not_assigned_implicitly(self):
  d={'areas':[{'area_id':'AA','subdivisions':[{'label':'東京市','directory_records':1}]}]}
  geo={'features':[{'type':'Feature','properties':{'iso_a2':'AA','name':'Tokyo'},'geometry':{'type':'Polygon','coordinates':[]}}]}
  o,a=m.convert(geo,d,{})
  self.assertEqual(o['features'],[])
if __name__=='__main__':unittest.main()
