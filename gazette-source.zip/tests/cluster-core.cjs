const fs=require('fs'),assert=require('node:assert/strict'),C=require('../dist/cluster-core.js');
const data=JSON.parse(fs.readFileSync(new URL('../dist/data.json',`file://${__filename}`))),kanji=d=>['CN','TW','HK','MO'].includes(d.id),keys=C.groups.map(g=>g[0]);
const result=C.cluster(data,keys,kanji,4);assert.equal(result.clusters.length,4);assert.equal(new Set(result.clusters.flatMap(c=>c.rows.map(d=>d.id))).size,204);assert(result.silhouette>=-1&&result.silhouette<=1);
const m=C.matrix(data,keys,kanji).m;for(let i=0;i<204;i++){assert.equal(m[i][i],0);for(let j=0;j<204;j++){assert.equal(m[i][j],m[j][i]);assert(m[i][j]>=0&&m[i][j]<=1)}}
assert.throws(()=>C.cluster(data,['titles'],kanji,4),/no comparable/);assert.equal(C.cluster(C.analysisRows(data),['titles'],kanji,3).clusters.length,3);
assert.equal(C.cluster(data,['script'],kanji,2).clusters.find(c=>c.rows.some(d=>d.id==='CN')).rows.length,4);
assert.equal(C.cluster(data,['script'],d=>kanji(d)||d.id==='KR',2).clusters.find(c=>c.rows.some(d=>d.id==='CN')).rows.length,5);
assert.throws(()=>C.cluster(data,[],kanji,4),/Select/);assert.throws(()=>C.cluster(data.slice(0,2),keys,kanji,4),/cluster count/);
assert(Math.abs(C.jaccard(new Set(['a','b']),new Set(['b','c']))-2/3)<1e-12);assert.equal(C.jaccard(null,new Set(['a'])),null);
const tiny=[{id:'A',learners:10,institutions:2,teachers:3,stages:[10,0,0,0],region:'X'},{id:'B',learners:100,institutions:20,teachers:30,stages:[100,0,0,0],region:'X'}];
assert.equal(C.matrix(tiny,['scale','region'],()=>false).m[0][1],.5);
assert.equal(C.matrix(tiny,['stage'],()=>false).m[0][1],0);
assert.deepEqual(result.clusters.map(c=>c.rows.map(d=>d.id)),C.cluster(data,keys,kanji,4).clusters.map(c=>c.rows.map(d=>d.id)));
console.log('PASS: mixed distance, missing data, numerical scaling, full membership, deterministic grouping, script sensitivity, invalid settings.');
