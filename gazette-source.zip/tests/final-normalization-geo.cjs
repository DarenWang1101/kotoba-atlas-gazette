const assert=require('node:assert/strict'),fs=require('node:fs');
const C=require('../dist/province-map-core.js');
const geo=JSON.parse(fs.readFileSync('dist/subdivision-boundaries.geojson'));
const dir=JSON.parse(fs.readFileSync('data/institution_geography.json'));
const matched=C.matchBoundaries(dir,geo);
const id=matched.find(x=>x.area_id==='ID');
for(const name of ['ジャカルタ首都特別市','西ヌサトゥンガラ州','東ヌサトゥンガラ州','ベンクル州']){
 const a=id.subdivisions.find(x=>x.label===name);assert(a);assert.equal(a.boundary_status,'matched',name);
 assert.equal(a.boundary.properties.country_iso2,'ID');
}
assert.equal(geo.features.length,155);
const reg=JSON.parse(fs.readFileSync('data/title_registry.json'));
const entries=reg.families;
assert.equal(new Set(entries.map(x=>x.family_id)).size,entries.length);
assert(entries.some(x=>x.canonical_family==='まるごと'&&x.aliases.length>1));
const ev=JSON.parse(fs.readFileSync('data/textbook_evidence.json'));
assert.equal(ev.length,1299);assert(ev.some(x=>x.evidence_type==='historical_use'));
console.log('PASS: 4 sourced Indonesia ADM1 polygons, unique series IDs, 1,299 preserved evidence observations');
