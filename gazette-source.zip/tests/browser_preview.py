"""Browser smoke test with synthetic fixture; never evaluates real boundary coverage."""
import json, pathlib, threading, http.server, socketserver
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]/'dist'
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(root),**kw)
 def log_message(self,*a):pass
class Server(socketserver.TCPServer):allow_reuse_address=True
server=Server(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f"http://127.0.0.1:{server.server_address[1]}/index.html"
errors=[]
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True)
  page=browser.new_page(viewport={'width':1280,'height':900})
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(url,wait_until='networkidle',timeout=30000)
  page.locator('#map .land').first.wait_for(state='attached',timeout=15000)
  assert page.locator('#map .land').count()>100,'Country polygons not rendered'
  page.evaluate("selectCountry('AU')")
  assert page.locator('#provinceExplorer').is_visible(),'Australia province panel not visible'
  assert page.locator('#provinceList [data-province]').count()==8,'Australia directory missing entries'
  assert page.locator('.province-point').count()==8,'Reference points missing'
  explorer=page.locator('#provinceExplorer')
  if explorer.get_attribute('open') is None:
   page.locator('#provinceSummary').click()
  victoria=page.locator('#provinceList [data-province="ビクトリア州"]')
  victoria.wait_for(state='visible',timeout=10000)
  victoria.click()
  assert victoria.get_attribute('aria-pressed')=='true','Victoria selection did not update'
  assert page.locator('#provinceProfile').inner_text().strip(),'Detail panel did not update'
  # Test polygon D3 events with an unmistakably synthetic geometry, injected into current scope.
  page.evaluate("""() => {
    const target=provinceMapped.find(a=>a.area_id==='AU').subdivisions[0];
    target.boundary_status='matched';
    target.boundary={type:'Polygon',coordinates:[[[143,-21],[145,-21],[145,-23],[143,-23],[143,-21]]]};
    renderProvinceMarkers();
  }""")
  assert page.locator('.province-boundary').count()>=1,'Polygon not rendered'
  queensland_boundary=page.locator('.province-boundary[aria-label^="クイーンズランド州:"]').first
  queensland_boundary.wait_for(state='attached',timeout=10000)
  queensland_boundary.click(force=True)
  assert page.locator('#provinceProfile').inner_text().find('クイーンズランド州')>=0,'Polygon selection not reflected in detail'
  queensland_boundary.focus();page.keyboard.press('Enter')
  assert page.locator('#provinceChoice').input_value()=='クイーンズランド州'
  page.evaluate("currentYear=2021;renderProvinceExplorer();renderProvinceMarkers()")
  assert page.locator('.province-boundary').count()==0,'Historical polygon layer incorrectly visible'
  page.evaluate("currentYear=2024;layer='books';renderProvinceExplorer();renderProvinceMarkers()")
  assert page.locator('.province-boundary').count()==0,'Textbook polygon layer incorrectly visible'
  assert not errors,errors
  print('PASS: Chromium actual DOM country map, AU panel, directory list, point markers, polygon click, keyboard, detail sync, historical/textbook gates')
  browser.close()
finally:server.shutdown()
