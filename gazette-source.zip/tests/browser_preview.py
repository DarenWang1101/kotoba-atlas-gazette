"""Kotoba Atlas v0.3.2 browser regression: Institutions-only subdivision dots.

Run from any directory: python3 tests/browser_preview.py
Requires: pip install playwright; python3 -m playwright install chromium
Country/subdivision browser checks do not certify the correctness of GeoJSON.
"""
import http.server
import pathlib
import re
import socketserver
import threading
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parents[1] / "dist"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def log_message(self, *args):
        pass

class Server(socketserver.TCPServer):
    allow_reuse_address = True

server = Server(("127.0.0.1", 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
errors = []

def ensure_institutions(page):
    page.locator('[data-layer="institutions"]').click()
    page.locator("#provinceExplorer").wait_for(state="visible", timeout=10000)

try:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.on("pageerror", lambda error: errors.append(str(error)))
        url = f"http://127.0.0.1:{server.server_address[1]}/index.html"
        page.goto(url, wait_until="networkidle", timeout=30000)
        page.locator("#map .land").first.wait_for(state="attached", timeout=15000)
        assert page.locator("#map .land").count() > 100, "Country map not rendered"

        # Select Australia, and explicitly enter the Institutions tab.
        page.evaluate("selectCountry('AU')")
        ensure_institutions(page)
        explorer = page.locator("#provinceExplorer")
        if explorer.get_attribute("open") is None:
            page.locator("#provinceSummary").click()
        assert page.locator("#provinceList [data-province]").count() == 8, "Australia entries missing"
        assert page.locator(".province-point").count() >= 7, "Australia map points missing"
        assert page.locator(".province-boundary").count() == 0, "Polygon outlines should be hidden"

        victoria = page.locator('#provinceList [data-province="ビクトリア州"]')
        victoria.wait_for(state="visible", timeout=10000)
        victoria.click()
        assert victoria.get_attribute("aria-pressed") == "true", "Victoria was not selected"
        assert "ビクトリア州" in page.locator("#provinceProfile").inner_text(), "Details out of sync"

        # Dot click / keyboard selects a subdivision.
        queensland = page.get_by_role("button", name=re.compile(r"^クイーンズランド州:")).last
        queensland.click(force=True)
        assert "クイーンズランド州" in page.locator("#provinceProfile").inner_text(), "Dot click failed"
        queensland.focus()
        page.keyboard.press("Enter")
        assert page.locator("#provinceChoice").input_value() == "クイーンズランド州", "Keyboard selection failed"

        # Other tabs must not display institution-specific dots or Within panel.
        for other in ("learners", "teachers", "books"):
            page.locator(f'[data-layer="{other}"]').click()
            assert not explorer.is_visible(), f"Within panel visible in {other}"
            assert page.locator(".province-point").count() == 0, f"Subdivision dots visible in {other}"
            assert page.locator(".province-boundary").count() == 0, f"Subdivision polygons visible in {other}"

        # Returning to Institutions restores the map controls.
        ensure_institutions(page)
        assert page.locator(".province-point").count() >= 7, "Dots did not restore"
        assert page.locator("#provinceList [data-province]").count() == 8, "Directory did not restore"

        # Historical-year restrictions must still apply.
        page.evaluate("currentYear=2021;renderProvinceExplorer();renderProvinceMarkers()")
        assert not explorer.is_visible(), "Within panel visible in historical year"
        assert page.locator(".province-point").count() == 0, "Historical dots visible"

        # Restore state, then check another country with matched boundaries.
        page.evaluate("currentYear=2024;layer='institutions';selectCountry('CN');renderProvinceExplorer();renderProvinceMarkers()")
        assert page.locator("#provinceList [data-province]").count() == 31, "China directory missing"
        assert page.locator(".province-point").count() >= 1, "China matched map dots missing"
        assert page.locator(".province-boundary").count() == 0, "China polygons unexpectedly visible"

        assert not errors, f"JavaScript page errors: {errors}"
        print("PASS: Chromium map, AU/CN dots, Institutions-only Within panel, tab switching, dot selection, keyboard, historical guards")
        browser.close()
finally:
    server.shutdown()
    server.server_close()
