const assert=require('node:assert/strict');
const fs=require('node:fs');
const app=fs.readFileSync('dist/app.js','utf8');
const css=fs.readFileSync('dist/style.css','utf8');
assert.match(app,/currentYear===2024&&layer==='institutions'&&!!area/,'Dot visibility must require Institutions and 2024');
assert.match(app,/panel\.hidden=currentYear!==2024\|\|layer!=='institutions'\|\|!area/,'Within panel must require Institutions and 2024');
assert.match(app,/renderProvinceExplorer\(\);renderProvinceMarkers\(\)/,'Layer changes must re-render panel and dots');
assert.match(css,/v0\.3\.2: compact cluster result cards/);
console.log('PASS: 2024 Institutions-only dots and Within directory, compact cluster result CSS.');
