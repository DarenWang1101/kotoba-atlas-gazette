const assert=require('node:assert/strict');
const fs=require('node:fs');
const m=require('../dist/province-map-core.js');
const directory=JSON.parse(fs.readFileSync('dist/institution-geography.json'));
const kr=m.match(directory).find(a=>a.area_id==='KR');
assert(kr && kr.subdivisions.length===16);
assert(kr.subdivisions.every(s=>s.map_status==='reference_point' && s.anchor && Number.isFinite(s.anchor.latitude)));
console.log('PASS: 16 Korean JF directory entries have unique named capital reference points');
