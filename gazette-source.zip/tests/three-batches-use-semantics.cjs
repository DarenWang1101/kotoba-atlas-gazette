const assert=require('node:assert/strict');
const C=require('../dist/cluster-core.js');
const books=[{title:'Current',stage:'Higher',evidenceStatus:'reported_use'},
{title:'Past',stage:'Other',evidenceStatus:'historical_use'},
{title:'Published',stage:'Other',evidenceStatus:'mentioned'}];
const used=C.usedBooks({books});
assert.deepEqual(used.map(b=>b.title),['Current','Past']);
assert(!C.usedBooks({books:[books[2]]}).length);
const map=require('../dist/province-map-core.js');
const directory=require('../dist/institution-geography.json');
const areas=map.match(directory);
for(const [id,count] of [['KR',16],['CA',10]]){
 const a=areas.find(x=>x.area_id===id);
 assert(a && a.subdivisions.length===count);
 assert(a.subdivisions.every(x=>x.anchor && Number.isFinite(x.anchor.latitude)));
}
console.log('PASS: 16 KR + 10 CA reference anchors; current and historical use included; publication mentions excluded');
