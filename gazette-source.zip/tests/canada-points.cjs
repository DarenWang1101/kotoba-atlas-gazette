const assert=require('node:assert/strict');
const fs=require('node:fs');
const map=require('../dist/province-map-core.js');
const directory=JSON.parse(fs.readFileSync('dist/institution-geography.json','utf8'));
const ca=map.match(directory).find(a=>a.area_id==='CA');
assert(ca&&ca.subdivisions.length===10);
assert(ca.subdivisions.every(s=>s.map_status==='reference_point'&&s.anchor&&Number.isFinite(s.anchor.latitude)&&Number.isFinite(s.anchor.longitude)));
assert(new Set(ca.subdivisions.map(s=>s.label)).size===10);
console.log('PASS: 10 Canadian JF directory divisions have province-scoped capital-city reference points');
