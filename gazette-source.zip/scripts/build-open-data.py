"""Build public tables and site textbook records from versioned profile reviews. No network required."""
import csv,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data';DIST=ROOT/'dist'
def read(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sid(prefix,*parts):return prefix+'-'+hashlib.sha256('|'.join(map(str,parts)).encode()).hexdigest()[:16]
def table(name,rows,fields=None):
 fields=fields or list(dict.fromkeys(k for row in rows for k in row))
 with (D/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in r.items()})
reviews=read(D/'profile_reviews.json');base=read(D/'areas.json');history=read(D/'survey_waves.json');sources=[];coverage=[];records=[];titles={};lookup={a['id']:a for a in reviews['countries']}
for area in base:
 id=area['id'];a=lookup.get(id);url=area.get('profile');source_id='jf-profile-2025-'+id
 if a and a.get('reviewStatus')!='source_unavailable':status='reviewed_named_materials' if a.get('books') else 'reviewed_no_named_titles'
 else:status='source_unavailable' if url else 'no_profile_link'
 cov={'area_id':id,'area_name':area['name'],'review_status':status,'source_id':source_id if url else None,'reviewed_on':a.get('verifiedOn') if a and status.startswith('reviewed') else None,'scope':a.get('reviewScope') if a else 'Source could not be retrieved in this audit; absence of records is not absence of use.','record_count':len(a.get('books',[])) if a else 0}
 coverage.append(cov)
 if url:sources.append({'source_id':source_id,'publisher':'The Japan Foundation','source_type':'country_area_profile','edition_year':2025,'url':url,'sha256':a.get('sourceSha256') if a else None,'retrieved_on':'2026-10-08' if a and a.get('sourceSha256') else None,'review_status':status})
 area['reviewStatus']=status;area['reviewScope']=cov['scope'];area.pop('books',None)
 if status.startswith('reviewed'):area['books']=[]
 for b in (a.get('books',[]) if a else []):
  b=dict(b); b['titleId']=sid('title',b['title']);b['evidenceId']=sid('evidence',id,b['title'],b['sourceTitle'],b['stage'],b['sourcePages'],b['evidenceStatus'])
  titles[b['titleId']]={'title_id':b['titleId'],'display_title':b['title'],'family_label':b.get('titleFamily',b['title']),'edition_resolution':'See source_title; a family label does not identify an ISBN or exact edition.'}
  record={'evidence_id':b['evidenceId'],'area_id':id,'title_id':b['titleId'],'display_title':b['title'],'title_family':b.get('titleFamily',b['title']),'source_title':b['sourceTitle'],'source_title_variants':b.get('sourceTitles',[]),'education_setting':b['stage'],'setting_detail':b.get('stageDetail'),'evidence_type':b['evidenceStatus'],'material_type':b.get('materialType','named_material'),'source_id':source_id,'source_url':b['sourceUrl'],'profile_edition':2025,'pdf_pages':b['sourcePages'],'section':b.get('evidenceLocator') or b.get('sourceSection'),'note':b.get('note',''),'adoption':b.get('adoption',{'status':'not_reported','value':None}),'reviewed_on':b['verifiedOn']}
  records.append(record);area['books'].append(b)
 # A reviewed zero-title profile is not evidence of zero textbook use.
write(D/'textbook_evidence.json',records);table('textbook_evidence.csv',records);table('review_coverage.csv',coverage);table('titles.csv',list(titles.values()));table('areas.csv',[{k:v for k,v in a.items() if k not in ('books','reviewScope','reviewStatus')} for a in base])
obs=[]
for w in history['waves']:
 source_id='jf-survey-'+str(w['year']);sources.append({'source_id':source_id,'publisher':'The Japan Foundation','source_type':'survey_table','edition_year':w['year'],'url':w['sourceUrl'],'sha256':None,'retrieved_on':history.get('retrieved'),'review_status':'existing_panel_totals_validated'})
 for r in w['rows']:
  common={'survey_year':w['year'],'area_id':r['id'],'source_id':source_id,'source_row':r.get('sourceRow'),'area_name':r['name'],'region':r['region']}
  values={k:r.get(k) for k in ['institutions','teachers','learners','school','multipleStage']};values.update(dict(zip(['primary','secondary','higher','other'],r['stages'])))
  for key,value in values.items():obs.append({**common,'measure':key,'value':value,'unit':'institutions' if key=='institutions' else 'persons','missing':value is None})
table('survey_observations.csv',obs);table('sources.csv',sources)
quant=read(D/'quantitative_evidence.json')
write(DIST/'data.json',base);write(DIST/'history.json',history)
summary={'version':reviews['version'],'reviewedOn':reviews['reviewedOn'],'totalRecords':len(records),'profilesWithNamedMaterials':sum(bool(a.get('books')) for a in base),'reviewedProfiles':sum(c['review_status'].startswith('reviewed') for c in coverage),'coverage':coverage,'countries':{a['id']:a for a in reviews['countries']},'method':'Named materials retain exact source-title transcription (line breaks normalized), physical PDF pages, education setting and evidence type. Publication, historical and digital-resource mentions are displayed but not treated as current textbook adoption. Coverage is partial where sources could not be retrieved. A 2025 profile may describe earlier observations. No readability score or national adoption rate is inferred.'}
write(DIST/'textbook-audit.json',summary)
resources=[]
for name in ['areas.csv','titles.csv','textbook_evidence.csv','textbook_evidence.json','review_coverage.csv','sources.csv','survey_observations.csv','survey_waves.json','quantitative_evidence.json','profile_reviews.json']:
 f=D/name;resources.append({'name':name.split('.')[0]+'_'+f.suffix[1:],'path':name,'format':f.suffix[1:],'bytes':f.stat().st_size,'hash':'sha256:'+hashlib.sha256(f.read_bytes()).hexdigest()})
write(D/'datapackage.json',{'name':'kotoba-atlas-jf-evidence','title':'Kotoba Atlas Gazette — JF survey and material evidence','version':reviews['version'],'created':'2026-10-08','homepage':'https://github.com/DarenWang1101/kotoba-atlas-gazette','description':summary['method'],'licenses':[{'name':'CC-BY-4.0','title':'Original curation and annotations only; see RIGHTS.md','path':'https://creativecommons.org/licenses/by/4.0/'}],'resources':resources,'counts':{k:summary[k] for k in ['totalRecords','profilesWithNamedMaterials','reviewedProfiles']}})
public=DIST/'open-data';shutil.rmtree(public,ignore_errors=True);shutil.copytree(D,public)
print(json.dumps({k:summary[k] for k in ['totalRecords','profilesWithNamedMaterials','reviewedProfiles']}))
