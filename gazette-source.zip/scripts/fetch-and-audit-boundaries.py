#!/usr/bin/env python3
"""Fetch Natural Earth 50m ADM1, import curated matches, and write a coverage audit.

Run on a machine with internet access from repository root.
Never substitutes synthetic geometries or claims full JF coverage.
"""
import hashlib,json,pathlib,subprocess,sys,urllib.request
URL='https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_1_states_provinces.geojson'
source=pathlib.Path('data/ne_50m_admin_1_states_provinces.source.geojson')
source.parent.mkdir(parents=True,exist_ok=True)
if not source.exists():
    try:
        req=urllib.request.Request(URL,headers={'User-Agent':'KotobaAtlasBoundaryImporter/0.3.2'})
        with urllib.request.urlopen(req,timeout=75) as response: payload=response.read(25_000_000)
        parsed=json.loads(payload)
        assert parsed.get('type')=='FeatureCollection' and len(parsed.get('features',[]))>100, 'Unexpected boundary file'
        assert all(isinstance(f.get('geometry'),dict) for f in parsed['features']), 'Invalid features'
        source.write_bytes(payload)
    except Exception as exc:
        raise SystemExit('Boundary download unavailable; no geometry was fabricated: '+str(exc))
else:
    payload=source.read_bytes()
    parsed=json.loads(payload)
    assert parsed.get('type')=='FeatureCollection' and len(parsed.get('features',[]))>100
subprocess.run([sys.executable,'scripts/import-subdivision-boundaries.py',str(source)],check=True)
audit=json.loads(pathlib.Path('data/subdivision-boundary-audit.json').read_text())
report={'source_url':URL,'sha256':hashlib.sha256(payload).hexdigest(),'source_features':len(parsed['features']), 'directory_groups':audit['total'], 'matched':audit['matched'],'ambiguous':audit['ambiguous'],'unmatched':audit['unmatched'], 'caveat':'ADM1 polygons only. City/other-level directory groups remain unmapped unless independently verified.'}
pathlib.Path('data/subdivision-boundary-source.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
