const fs=require('node:fs');
const url=process.env.PAGES_BASE_URL;
if(!url||!/^https:\/\//.test(url))throw Error('PAGES_BASE_URL must be the HTTPS URL returned by configure-pages.');
fs.cpSync('dist','_site',{recursive:true});
const escaped=url.replace(/[&"<>]/g,c=>({'&':'&amp;','"':'&quot;','<':'&lt;','>':'&gt;'}[c]));
const path='_site/index.html';
fs.writeFileSync(path,fs.readFileSync(path,'utf8').replace(/(<meta property="og:url" content=")[^"]*(">)/,'$1'+escaped+'$2'));
fs.writeFileSync('_site/.nojekyll','');
