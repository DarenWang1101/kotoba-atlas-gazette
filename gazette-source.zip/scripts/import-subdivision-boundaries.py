#!/usr/bin/env python3
"""Conservative, reproducible Natural Earth ADM1 importer for the development preview.

Usage: python scripts/import-subdivision-boundaries.py path/to/ne_50m_admin_1_states_provinces.geojson
Optional: --aliases data/subdivision-aliases.json --output dist/subdivision-boundaries.geojson
No inferred points, fuzzy geographic joins, or automatic label translation.
"""
import argparse, json, pathlib, re, unicodedata

def norm(s):
    return re.sub(r'[\s\u3000]+', '', unicodedata.normalize('NFKC',str(s or '')).lower())

def load(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))

ISO3_TO_2 = dict(zip('AUS BRA CAN CHN DEU ESP FRA GBR IDN IND KOR MMR MEX MYS NZL PHL RUS THA TWN USA VNM'.split(), 'AU BR CA CN DE ES FR GB ID IN KR MM MX MY NZ PH RU TH TW US VN'.split()))
def convert(source, directory, aliases):
    """Return subset with unique validated name/alias joins and a coverage audit."""
    source_features=source.get('features',[])
    results=[]; audit=[]; taken=set()
    # Keep political/geographic names as stated in the source, without reconstructing borders.
    for area in directory['areas']:
        iso=area['area_id']
        for s in area['subdivisions']:
            label=s['label']; key=f'{iso}|{label}'
            wanted={norm(label),*(norm(x) for x in aliases.get(key,[]))}
            hits=[]
            for index,f in enumerate(source_features):
                p=f.get('properties') or {}; g=f.get('geometry') or {}
                if g.get('type') not in ('Polygon','MultiPolygon'): continue
                source_iso=p.get('country_iso2') or p.get('iso_a2') or p.get('country_code') or p.get('iso_a2_eh') or ISO3_TO_2.get(p.get('adm0_a3')) or ISO3_TO_2.get(p.get('sr_adm0_a3'))
                if source_iso!=iso: continue
                names=[p.get(k) for k in ('name','name_en','name_ja','name_local','name_alt','name_ascii','gn_name')]
                names.extend(p.get('aliases',[]) if isinstance(p.get('aliases'),list) else [])
                if any(norm(n) in wanted for n in names if n):hits.append((index,f))
            status='matched' if len(hits)==1 else 'ambiguous' if hits else 'unmatched'
            if len(hits)==1:
                index,f=hits[0]; unique=(iso,index)
                if unique in taken:status='ambiguous'
                else:
                    taken.add(unique); p=f.get('properties') or {}
                    results.append({'type':'Feature','id':f'{iso}-{index}','properties':{'country_iso2':iso,'name_ja':label,'name':p.get('name'),'source_name':p.get('name'),'source_index':index,'jf_label':label,'match_method':'exact_or_reviewed_alias'},'geometry':f['geometry']})
            audit.append({'area_id':iso,'jf_label':label,'status':status,'source_matches':len(hits),'directory_records':s['directory_records']})
    return {'type':'FeatureCollection','features':results,'provenance':{'source':'Natural Earth ADM1 GeoJSON (provided locally)','matching':'country-scoped names or explicitly reviewed aliases; no fuzzy matching','geometry_kind':'actual ADM1 polygons, not institution locations'}},audit

def main():
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('--directory',default='data/institution_geography.json');p.add_argument('--aliases',default='data/subdivision-aliases.json');p.add_argument('--output',default='dist/subdivision-boundaries.geojson');p.add_argument('--audit',default='data/subdivision-boundary-audit.json');a=p.parse_args()
    aliases=load(a.aliases) if pathlib.Path(a.aliases).exists() else {}
    out,audit=convert(load(a.source),load(a.directory),aliases)
    for target,payload in ((a.output,out),(a.audit,{'total':len(audit),'matched':sum(r['status']=='matched' for r in audit),'ambiguous':sum(r['status']=='ambiguous' for r in audit),'unmatched':sum(r['status']=='unmatched' for r in audit),'records':audit})):
        path=pathlib.Path(target);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(f"ADM1: {len(audit)} directory labels; {len(out['features'])} unique matched polygons; {sum(r['status']=='ambiguous' for r in audit)} ambiguous; {sum(r['status']=='unmatched' for r in audit)} unmatched")
if __name__=='__main__':main()
